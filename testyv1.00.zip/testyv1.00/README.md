# Jakie zadanie pełni ten projekt?
# Projekt ten pełni zadanie strony edukacyjnej która ma interakcję z użytkownikiem.
# Jak kożystać z strony?
# Po odpaleniu strony wybierasz test u góry w menu i zaznaczasz odpowiedzi klikając na nie.